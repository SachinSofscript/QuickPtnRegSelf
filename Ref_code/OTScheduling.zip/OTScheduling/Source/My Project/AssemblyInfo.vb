﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("WebAppTemplate")> 
<Assembly: AssemblyDescription("CAREWORKS HMIS WEB PROJECT")> 
<Assembly: AssemblyCompany("Sofscript Systems & Services Ltd.")> 
<Assembly: AssemblyProduct("CAREWORKS HMIS")> 
<Assembly: AssemblyCopyright("Copyright ©  2015 Sofscript Systems & Services Ltd.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("2727fc34-10d6-477e-98a9-c115104b651a")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
